char *respond(char *userCall, FILE *userCalls, FILE *botResponses);
